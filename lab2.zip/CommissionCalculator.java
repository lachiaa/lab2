import java.util.Scanner;

public class CommissionCalculator {
    private Auto autoPolicy;
    private Home homePolicy;
    private Life lifePolicy;
    private Scanner scanner;

    public CommissionCalculator() {
        autoPolicy = new Auto("", "", "", "", 0, 0);
        homePolicy = new Home();
        lifePolicy = new Life("", "", 0, 0);
        scanner = new Scanner(System.in);
    }

    public void Run() {
        int choice;
        do {
            System.out.println("-----------------------------");
            System.out.println("Welcome to Parkland Insurance");
            System.out.println("-----------------------------");
            System.out.println("Enter any of the following:");
            System.out.println("1) Enter auto insurance policy information");
            System.out.println("2) Enter home insurance policy information");
            System.out.println("3) Enter life insurance policy information");
            System.out.println("4) Compute commission and print auto policy");
            System.out.println("5) Compute commission and print home policy");
            System.out.println("6) Compute commission and print life policy");
            System.out.println("7) Quit");
            choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    enterAutoPolicyInfo();
                    break;
                case 2:
                    enterHomePolicyInfo();
                    break;
                case 3:
                    enterLifePolicyInfo();
                    break;
                case 4:
                    printAutoPolicy();
                    break;
                case 5:
                    printHomePolicy();
                    break;
                case 6:
                    printLifePolicy();
                    break;
                case 7:
                    System.out.println("Goodbye!");
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        } while (choice != 7);
    }

    private double readMonetaryValue(String prompt) {
        System.out.print(prompt);
        String input = scanner.nextLine().replaceAll("[^\\d.]", ""); // Remove non-numeric characters except "."
        return Double.parseDouble(input);
    }

    private void enterAutoPolicyInfo() {
        System.out.print("Enter first name of insured: ");
        String firstName = scanner.nextLine();
        System.out.print("Enter last name of insured: ");
        String lastName = scanner.nextLine();
        System.out.print("Enter make of vehicle: ");
        String make = scanner.nextLine();
        System.out.print("Enter model of vehicle: ");
        String model = scanner.nextLine();
        double liability = readMonetaryValue("Enter amount of liability: ");
        double collision = readMonetaryValue("Enter amount of collision: ");

        autoPolicy = new Auto(firstName, lastName, make, model, liability, collision);
        System.out.println("Auto insurance policy information saved.");
    }

    private void enterHomePolicyInfo() {
        System.out.print("Enter first name of insured: ");
        String firstName = scanner.nextLine();
        System.out.print("Enter last name of insured: ");
        String lastName = scanner.nextLine();
        System.out.print("Enter house square footage: ");
        int footage = scanner.nextInt();
        scanner.nextLine(); // Consume newline
        double dwelling = readMonetaryValue("Enter amount of dwelling: ");
        double contents = readMonetaryValue("Enter amount of contents: ");
        double liability = readMonetaryValue("Enter amount of liability: ");

        homePolicy.setFirstName(firstName);
        homePolicy.setLastName(lastName);
        homePolicy.setFootage(footage);
        homePolicy.setDwelling(dwelling);
        homePolicy.setContents(contents);
        homePolicy.setLiability(liability);
        System.out.println("Home insurance policy information saved.");
    }

    private void enterLifePolicyInfo() {
        System.out.print("Enter first name of insured: ");
        String firstName = scanner.nextLine();
        System.out.print("Enter last name of insured: ");
        String lastName = scanner.nextLine();
        System.out.print("Enter age of insured: ");
        int age = scanner.nextInt();
        scanner.nextLine(); // Consume newline
        double term = readMonetaryValue("Enter amount of term: ");

        lifePolicy = new Life(firstName, lastName, age, term);
        System.out.println("Life insurance policy information saved.");
    }

    private void printAutoPolicy() {
        autoPolicy.computeCommission();
        System.out.println(autoPolicy);
    }

    private void printHomePolicy() {
        homePolicy.computeCommission();
        System.out.println(homePolicy);
    }

    private void printLifePolicy() {
        lifePolicy.computeCommission();
        System.out.println(lifePolicy);
    }
}

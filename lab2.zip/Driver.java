public class Driver {
    public static void main(String[] args) {
        CommissionCalculator calc = new CommissionCalculator();
        calc.Run();
    }
}
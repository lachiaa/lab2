public class Life {
    private String firstName;
    private String lastName;
    private int age;
    private double term;
    private double commission;

    public Life(String firstName, String lastName, int age, double term) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.age = age;
        this.term = term;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public int getAge() {
        return age;
    }

    public double getTerm() {
        return term;
    }

    public void computeCommission() {
        commission = term * 0.20;
    }

    public String toString() {
        return "Life Policy\n-----------\n" +
                "Name: " + firstName + " " + lastName + "\n" +
                "Age: " + age + "\n" +
                "Term: $" + String.format("%.2f", term) + "\n" +
                "Commission: $" + String.format("%.2f", commission);
    }
}
